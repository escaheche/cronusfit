import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/db/operations.ts
import {
  GetCommand,
  PutCommand,
  UpdateCommand,
  DeleteCommand,
  QueryCommand,
  TransactWriteCommand
} from "@aws-sdk/lib-dynamodb";

// src/db/client.ts
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
var ddbClient = new DynamoDBClient({});
var docClient = DynamoDBDocumentClient.from(ddbClient, {
  marshallOptions: {
    removeUndefinedValues: true
  }
});
var TABLE_NAME = process.env.DYNAMODB_TABLE ?? process.env.TABLE_NAME ?? "CronusFit";
var GSI1 = {
  indexName: "GSI1",
  PK: "GSI1PK",
  SK: "GSI1SK"
};

// src/db/operations.ts
async function get(pk, sk, options) {
  const result = await docClient.send(
    new GetCommand({
      TableName: TABLE_NAME,
      Key: { PK: pk, SK: sk },
      ProjectionExpression: options?.projectionExpression,
      ExpressionAttributeNames: options?.expressionAttributeNames,
      ConsistentRead: options?.consistentRead
    })
  );
  return result.Item ?? null;
}
async function queryByGSI1(gsi1pk, skCondition, options) {
  const expressionValues = {
    ":pk": gsi1pk,
    ...options?.expressionAttributeValues
  };
  let keyCondition = "GSI1PK = :pk";
  if (skCondition) {
    keyCondition += ` AND ${skCondition.expression}`;
    expressionValues[":sk"] = skCondition.value;
    if (skCondition.value2) {
      expressionValues[":sk2"] = skCondition.value2;
    }
  }
  const params = {
    TableName: TABLE_NAME,
    IndexName: GSI1.indexName,
    KeyConditionExpression: keyCondition,
    ExpressionAttributeValues: expressionValues,
    ExpressionAttributeNames: options?.expressionAttributeNames,
    FilterExpression: options?.filterExpression,
    Limit: options?.limit,
    ScanIndexForward: options?.scanIndexForward ?? true,
    ExclusiveStartKey: options?.exclusiveStartKey,
    ProjectionExpression: options?.projectionExpression
  };
  const result = await docClient.send(new QueryCommand(params));
  return {
    items: result.Items ?? [],
    lastEvaluatedKey: result.LastEvaluatedKey,
    count: result.Count ?? 0
  };
}
async function getPattern(id) {
  const record = await get(`PATTERN#${id}`, "METADATA");
  if (!record) return null;
  return {
    id: record.id,
    garmentType: record.garmentType,
    ageGroup: record.ageGroup,
    size: record.size,
    createdAt: record.createdAt,
    generationMethod: record.generationMethod,
    s3Key: record.s3Key,
    pieceCount: record.pieceCount,
    seamAllowance: record.seamAllowance,
    adminId: record.adminId
  };
}
async function queryPatterns(options) {
  const filterParts = [];
  const expressionAttributeValues = {};
  const expressionAttributeNames = {};
  if (options?.garmentType) {
    filterParts.push("#garmentType = :garmentType");
    expressionAttributeNames["#garmentType"] = "garmentType";
    expressionAttributeValues[":garmentType"] = options.garmentType;
  }
  if (options?.ageGroup) {
    filterParts.push("#ageGroup = :ageGroup");
    expressionAttributeNames["#ageGroup"] = "ageGroup";
    expressionAttributeValues[":ageGroup"] = options.ageGroup;
  }
  const filterExpression = filterParts.length > 0 ? filterParts.join(" AND ") : void 0;
  const result = await queryByGSI1(
    "PATTERNS",
    void 0,
    {
      limit: options?.limit,
      scanIndexForward: false,
      // descending by date
      exclusiveStartKey: options?.exclusiveStartKey,
      filterExpression,
      expressionAttributeNames: Object.keys(expressionAttributeNames).length > 0 ? expressionAttributeNames : void 0,
      expressionAttributeValues: Object.keys(expressionAttributeValues).length > 0 ? expressionAttributeValues : void 0
    }
  );
  const patterns = result.items.map((record) => ({
    id: record.id,
    garmentType: record.garmentType,
    ageGroup: record.ageGroup,
    size: record.size,
    createdAt: record.createdAt,
    generationMethod: record.generationMethod,
    s3Key: record.s3Key,
    pieceCount: record.pieceCount,
    seamAllowance: record.seamAllowance,
    adminId: record.adminId
  }));
  return {
    patterns,
    lastEvaluatedKey: result.lastEvaluatedKey,
    count: result.count
  };
}

// src/storage/s3-client.ts
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
var s3Client = new S3Client({});
var BUCKETS = {
  /** Private bucket for patterns, designs, mockups, print files, social content (Block Public Access). */
  assets: process.env.S3_ASSETS_BUCKET ?? "cronusfit-assets",
  /** Private bucket for static site (CloudFront OAI access only). */
  website: process.env.S3_WEBSITE_BUCKET ?? "cronusfit-website"
};
var DEFAULT_PRESIGNED_EXPIRY_SECONDS = 3600;
var PRESIGNED_EXPIRY_SECONDS = process.env.PRESIGNED_URL_EXPIRY ? parseInt(process.env.PRESIGNED_URL_EXPIRY, 10) : DEFAULT_PRESIGNED_EXPIRY_SECONDS;
var MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;
function getPatternS3Key(patternId) {
  return `patterns/${patternId}/pattern.svg`;
}
async function getPatternDownloadUrl(patternId) {
  const key = getPatternS3Key(patternId);
  const command = new GetObjectCommand({
    Bucket: BUCKETS.assets,
    Key: key
  });
  return getSignedUrl(s3Client, command, {
    expiresIn: 3600
    // 1 hour
  });
}

// src/lambdas/shared/response.ts
var STANDARD_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization"
};
function successResponse(statusCode, body) {
  return {
    statusCode,
    headers: STANDARD_HEADERS,
    body: JSON.stringify(body)
  };
}
function errorResponse(statusCode, error, options) {
  const body = { error };
  if (options?.message) body.message = options.message;
  if (options?.details !== void 0) body.details = options.details;
  if (options?.measurements) body.measurements = options.measurements;
  return {
    statusCode,
    headers: STANDARD_HEADERS,
    body: JSON.stringify(body)
  };
}
function errorMessage(error) {
  if (error instanceof Error) return error.message;
  return "Internal server error";
}
function extractAdminId(requestContext) {
  if (!requestContext.authorizer) return void 0;
  const claims = requestContext.authorizer.claims;
  return claims?.sub;
}

// src/lambdas/pattern-list/handler.ts
var VALID_GARMENT_TYPES = [
  "camiseta",
  "short",
  "legging",
  "sudadera",
  "tank-top",
  "tank_top",
  "custom"
];
var VALID_AGE_GROUPS = ["children", "adult"];
var handler = async (event) => {
  try {
    const sub = extractAdminId(event.requestContext);
    if (!sub) {
      return errorResponse(401, "Authentication required", {
        message: "Valid Cognito JWT authentication is required."
      });
    }
    const pathId = event.pathParameters?.id;
    if (pathId) {
      return handleDownload(pathId);
    }
    return handleList(event);
  } catch (error) {
    return errorResponse(500, "Processing Error", { message: errorMessage(error) });
  }
};
async function handleList(event) {
  const queryParams = event.queryStringParameters ?? {};
  const garmentType = queryParams.garmentType;
  const ageGroup = queryParams.ageGroup;
  const limitParam = queryParams.limit;
  const cursor = queryParams.cursor;
  if (garmentType && !VALID_GARMENT_TYPES.includes(garmentType)) {
    return errorResponse(400, "Validation Error", {
      message: `Invalid garmentType filter: "${garmentType}". Valid values: ${VALID_GARMENT_TYPES.join(", ")}`
    });
  }
  if (ageGroup && !VALID_AGE_GROUPS.includes(ageGroup)) {
    return errorResponse(400, "Validation Error", {
      message: `Invalid ageGroup filter: "${ageGroup}". Valid values: ${VALID_AGE_GROUPS.join(", ")}`
    });
  }
  let limit = 20;
  if (limitParam) {
    const parsed = parseInt(limitParam, 10);
    if (!isNaN(parsed) && parsed > 0) {
      limit = Math.min(parsed, 100);
    }
  }
  let exclusiveStartKey;
  if (cursor) {
    try {
      exclusiveStartKey = JSON.parse(Buffer.from(cursor, "base64url").toString("utf-8"));
    } catch {
      return errorResponse(400, "Validation Error", { message: "Invalid pagination cursor" });
    }
  }
  const result = await queryPatterns({
    limit,
    garmentType,
    ageGroup,
    exclusiveStartKey
  });
  const response = {
    patterns: result.patterns.map((p) => ({
      id: p.id,
      garmentType: p.garmentType,
      ageGroup: p.ageGroup,
      size: p.size,
      createdAt: p.createdAt,
      generationMethod: p.generationMethod,
      pieceCount: p.pieceCount,
      seamAllowance: p.seamAllowance
    })),
    count: result.patterns.length
  };
  if (result.lastEvaluatedKey) {
    response.lastEvaluatedKey = Buffer.from(
      JSON.stringify(result.lastEvaluatedKey)
    ).toString("base64url");
  }
  return successResponse(200, response);
}
async function handleDownload(patternId) {
  const pattern = await getPattern(patternId);
  if (!pattern) {
    return errorResponse(404, "Not Found", { message: `Pattern not found: ${patternId}` });
  }
  const downloadUrl = await getPatternDownloadUrl(patternId);
  const response = {
    downloadUrl,
    metadata: {
      id: pattern.id,
      garmentType: pattern.garmentType,
      ageGroup: pattern.ageGroup,
      size: pattern.size,
      createdAt: pattern.createdAt,
      generationMethod: pattern.generationMethod,
      s3Key: pattern.s3Key,
      pieceCount: pattern.pieceCount,
      seamAllowance: pattern.seamAllowance,
      adminId: pattern.adminId
    }
  };
  return successResponse(200, response);
}
export {
  handler
};
//# sourceMappingURL=handler.mjs.map
